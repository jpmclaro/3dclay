"""Custom Qt widgets for 3D visualization."""

from __future__ import annotations

from typing import Optional

import numpy as np
from PySide6 import QtCore, QtGui, QtWidgets
from pyqtgraph.opengl import GLGridItem, GLLinePlotItem, GLMeshItem, GLViewWidget


class MeshViewWidget(GLViewWidget):
    """3D viewer with Fusion-like mouse controls."""

    def __init__(self, title: str, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent=parent)
        self._setup_background()
        self.opts["distance"] = 600
        self.opts["center"] = QtGui.QVector3D(0, 0, 0)
        self.opts["elevation"] = 20
        self.opts["azimuth"] = 45
        self._mouse_button: Optional[QtCore.Qt.MouseButton] = None
        self._last_pos: Optional[QtCore.QPoint] = None
        self._mesh_item: Optional[GLMeshItem] = None
        self._title_label = QtWidgets.QLabel(title, parent=self)
        self._title_label.setStyleSheet(
            "QLabel { color: #e0e0e0; background: rgba(0, 0, 0, 150); padding: 2px 6px; }"
        )
        self._axes = self._create_axes()
        for item in self._axes:
            self.addItem(item)
        self._grid = self._create_grid()
        self.addItem(self._grid)
        self._bounds = self._create_bounds()
        for edge in self._bounds:
            self.addItem(edge)

    def resizeEvent(self, evt: QtGui.QResizeEvent) -> None:  # noqa: D401
        super().resizeEvent(evt)
        if self._title_label:
            self._title_label.move(8, 8)

    def mousePressEvent(self, evt: QtGui.QMouseEvent) -> None:  # noqa: D401
        self._mouse_button = evt.button()
        self._last_pos = evt.position().toPoint()
        super().mousePressEvent(evt)

    def mouseReleaseEvent(self, evt: QtGui.QMouseEvent) -> None:  # noqa: D401
        super().mouseReleaseEvent(evt)
        self._mouse_button = None
        self._last_pos = None

    def mouseMoveEvent(self, evt: QtGui.QMouseEvent) -> None:  # noqa: D401
        if self._last_pos is None:
            self._last_pos = evt.position().toPoint()
        delta = evt.position().toPoint() - self._last_pos
        self._last_pos = evt.position().toPoint()

        if self._mouse_button == QtCore.Qt.MouseButton.LeftButton:
            self.orbit(-delta.x() * 0.5, delta.y() * 0.5)
        elif self._mouse_button == QtCore.Qt.MouseButton.MiddleButton:
            self.pan(delta.x() * -0.5, delta.y() * 0.5, 0, relative="view")
        elif self._mouse_button == QtCore.Qt.MouseButton.RightButton:
            factor = 1 + (delta.y() * 0.01)
            self.opts["distance"] = max(1e-3, self.opts["distance"] * factor)
            self.update()
        else:
            super().mouseMoveEvent(evt)

    def wheelEvent(self, evt: QtGui.QWheelEvent) -> None:  # noqa: D401
        delta = evt.angleDelta().y()
        factor = 1 - delta / (8 * 120)
        self.opts["distance"] = max(1e-3, self.opts["distance"] * factor)
        self.update()

    def set_mesh(
        self,
        mesh: Optional["trimesh.Trimesh"],
        color: tuple[int, int, int, int],
        shading: str = "warm",
    ) -> None:
        """Display the provided mesh with the given color."""

        if self._mesh_item:
            self.removeItem(self._mesh_item)
            self._mesh_item = None
        if mesh is None:
            return
        vertices = np.asarray(mesh.vertices, dtype=np.float32)
        faces = np.asarray(mesh.faces, dtype=np.int32)
        centroid = vertices.mean(axis=0)
        span = vertices.max(axis=0) - vertices.min(axis=0)
        distance = max(100.0, float(np.linalg.norm(span)) * 2.0)
        self.opts["center"] = QtGui.QVector3D(float(centroid[0]), float(centroid[1]), float(centroid[2]))
        self.opts["distance"] = distance
        item = GLMeshItem(
            vertexes=vertices,
            faces=faces,
            vertexColors=self._shade_vertices(mesh, color, shading),
            smooth=True,
            shader=None,
            glOptions="opaque",
        )
        self.addItem(item)
        self._mesh_item = item

    def _shade_vertices(
        self,
        mesh: "trimesh.Trimesh",
        color: tuple[int, int, int, int],
        scheme: str,
    ) -> np.ndarray:
        base = np.array(color, dtype=np.float32) / 255.0
        if scheme == "cool":
            tint = np.array([0.82, 0.9, 1.08])
        else:
            tint = np.array([1.15, 1.05, 0.78])
        base_rgb = np.clip(base[:3] * tint, 0.0, 1.0)
        normals = mesh.vertex_normals
        light_dir = np.array([-0.4, -0.6, 0.7], dtype=np.float32)
        light_dir /= np.linalg.norm(light_dir)
        view_dir = np.array([0.0, 0.0, 1.0], dtype=np.float32)
        diffuse = np.clip(normals.dot(light_dir), 0.0, 1.0).reshape(-1, 1)
        half_vec = (light_dir + view_dir) / np.linalg.norm(light_dir + view_dir)
        spec = np.clip(normals.dot(half_vec), 0.0, 1.0) ** 35
        ambient = 0.55
        diff_strength = 0.8
        color_rgb = base_rgb * (ambient + diff_strength * diffuse)
        specular_color = np.array([1.0, 0.92, 0.7])
        color_rgb += spec[:, None] * specular_color * 0.6
        color_rgb = np.clip(color_rgb, 0.0, 1.0)
        alpha = np.full((color_rgb.shape[0], 1), base[3])
        return np.hstack([color_rgb, alpha])

    def _setup_background(self) -> None:
        self.setBackgroundColor(QtGui.QColor(200, 224, 252))

    def _create_axes(self) -> list[GLLinePlotItem]:
        """Return RGB axes using line items for custom coloring."""

        axis_lines = [
            ((0.0, 0.0, 0.0), (120.0, 0.0, 0.0), (0.92, 0.34, 0.34, 1.0)),
            ((0.0, 0.0, 0.0), (0.0, 120.0, 0.0), (0.27, 0.78, 0.37, 1.0)),
            ((0.0, 0.0, 0.0), (0.0, 0.0, 120.0), (0.20, 0.36, 0.86, 1.0)),
        ]
        axes: list[GLLinePlotItem] = []
        for start, end, color in axis_lines:
            line = GLLinePlotItem(
                pos=np.array([start, end], dtype=np.float32),
                color=color,
                width=3,
                mode="lines",
                antialias=True,
            )
            axes.append(line)
        return axes

    def _create_grid(self) -> GLGridItem:
        grid = GLGridItem()
        grid.setSize(x=400, y=400, z=1)
        grid.setSpacing(x=10, y=10, z=1)
        grid.translate(0, 0, 0)
        grid.setColor(QtGui.QColor(150, 150, 150, 180))
        return grid

    def _create_bounds(self) -> list[GLLinePlotItem]:
        """Create a translucent bounding box similar to CAD view cube."""

        half = 200.0
        corners = np.array(
            [
                [-half, -half, 0.0],
                [half, -half, 0.0],
                [half, half, 0.0],
                [-half, half, 0.0],
                [-half, -half, half * 2],
                [half, -half, half * 2],
                [half, half, half * 2],
                [-half, half, half * 2],
            ],
            dtype=np.float32,
        )
        edges = [
            (0, 1),
            (1, 2),
            (2, 3),
            (3, 0),
            (4, 5),
            (5, 6),
            (6, 7),
            (7, 4),
            (0, 4),
            (1, 5),
            (2, 6),
            (3, 7),
        ]
        color = (0.7, 0.78, 0.88, 0.5)
        items: list[GLLinePlotItem] = []
        for start, end in edges:
            pts = np.array([corners[start], corners[end]], dtype=np.float32)
            line = GLLinePlotItem(pos=pts, color=color, mode="lines", antialias=True, width=1)
            items.append(line)
        return items


class SidePanel(QtWidgets.QWidget):
    """Left panel for controls."""

    loadRequested = QtCore.Signal()

    def __init__(self) -> None:
        super().__init__()
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        heading = QtWidgets.QLabel("GTClay Segmenter")
        heading.setStyleSheet("QLabel { font-size: 18px; font-weight: bold; }")
        layout.addWidget(heading)

        description = QtWidgets.QLabel(
            "Carregue um objeto 3D (.obj ou .stl) para detectar tampa, corpo e base."
        )
        description.setWordWrap(True)
        layout.addWidget(description)

        self.load_button = QtWidgets.QPushButton("Carregar objeto...")
        self.load_button.clicked.connect(self.loadRequested.emit)
        layout.addWidget(self.load_button)

        layout.addStretch(1)
