"""GTClay package for 3D object segmentation and visualization."""

__all__ = ["app", "mesh_processing", "widgets"]

