"""Application entry point for the GTClay visual segmenter."""

from __future__ import annotations

from pathlib import Path

from PySide6 import QtWidgets

from .mesh_processing import MeshProcessingError, SegmentMeshes, segment_mesh
from .widgets import MeshViewWidget, SidePanel


class MainWindow(QtWidgets.QMainWindow):
    """Main window hosting controls and 3D viewers."""

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("GTClay - Segmentador de Tampas")
        self.resize(1400, 900)

        self.side_panel = SidePanel()
        self.side_panel.loadRequested.connect(self._handle_load_requested)

        self.original_view = MeshViewWidget("Objeto Completo")
        self.top_view = MeshViewWidget("Tampa")
        self.body_view = MeshViewWidget("Corpo")
        self.bottom_view = MeshViewWidget("Base (Z=0)")

        central = QtWidgets.QWidget()
        outer_layout = QtWidgets.QHBoxLayout(central)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(0)

        self.side_panel.setFixedWidth(280)
        outer_layout.addWidget(self.side_panel)

        grid_container = QtWidgets.QWidget()
        grid_layout = QtWidgets.QGridLayout(grid_container)
        grid_layout.setContentsMargins(6, 6, 6, 6)
        grid_layout.setSpacing(6)

        grid_layout.addWidget(self.original_view, 0, 0)
        grid_layout.addWidget(self.top_view, 0, 1)
        grid_layout.addWidget(self.body_view, 1, 0)
        grid_layout.addWidget(self.bottom_view, 1, 1)
        outer_layout.addWidget(grid_container, 1)

        self.setCentralWidget(central)
        self.statusBar().showMessage("Carregue um arquivo para iniciar.")

    def _display_segments(self, segments: SegmentMeshes) -> None:
        palette = {
            "original": (255, 179, 59, 255),
            "top": (235, 92, 70, 255),
            "body": (72, 176, 232, 255),
            "bottom": (64, 208, 138, 255),
        }
        self.original_view.set_mesh(segments.original, palette["original"], shading="warm")
        self.top_view.set_mesh(segments.top, palette["top"], shading="warm")
        self.body_view.set_mesh(segments.body, palette["body"], shading="cool")
        self.bottom_view.set_mesh(segments.bottom, palette["bottom"], shading="cool")

    def _clear_views(self) -> None:
        self.original_view.set_mesh(None, (0, 0, 0, 0))
        self.top_view.set_mesh(None, (0, 0, 0, 0))
        self.body_view.set_mesh(None, (0, 0, 0, 0))
        self.bottom_view.set_mesh(None, (0, 0, 0, 0))

    def _handle_load_requested(self) -> None:
        dialog = QtWidgets.QFileDialog(self, "Selecionar objeto 3D")
        dialog.setFileMode(QtWidgets.QFileDialog.FileMode.ExistingFile)
        dialog.setNameFilters(["Meshes (*.obj *.stl)", "OBJ (*.obj)", "STL (*.stl)", "Todos (*.*)"])
        if not dialog.exec():
            return
        selected = dialog.selectedFiles()
        if not selected:
            return
        path = Path(selected[0])
        try:
            segments = segment_mesh(path)
        except MeshProcessingError as exc:
            QtWidgets.QMessageBox.critical(self, "Falha ao segmentar", str(exc))
            self.statusBar().showMessage("Erro ao processar o arquivo.")
            self._clear_views()
            return
        except Exception as exc:  # noqa: BLE001
            QtWidgets.QMessageBox.critical(
                self,
                "Erro inesperado",
                f"Falha interna ao processar o arquivo:\n{exc}",
            )
            self.statusBar().showMessage("Erro ao processar o arquivo.")
            self._clear_views()
            return
        self._display_segments(segments)
        top_status = "detectada" if segments.top and not segments.top.is_empty else "nao detectada automaticamente"
        self.statusBar().showMessage(
            f"Tampa {top_status}. Faces: topo={segments.top.faces.shape[0] if segments.top else 0}, "
            f"corpo={segments.body.faces.shape[0] if segments.body else 0}, "
            f"base={segments.bottom.faces.shape[0] if segments.bottom else 0}."
        )


def run() -> None:
    """Launch the Qt application."""

    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    window = MainWindow()
    window.show()
    app.exec()


__all__ = ["MainWindow", "run"]
