"""Mesh loading and segmentation utilities using layer-based top detection."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import trimesh


@dataclass
class SegmentMeshes:
    """Container for separated mesh parts."""

    original: trimesh.Trimesh
    bottom: Optional[trimesh.Trimesh]
    body: Optional[trimesh.Trimesh]
    top: Optional[trimesh.Trimesh]


class MeshProcessingError(RuntimeError):
    """Raised when mesh processing fails."""


def load_mesh(path: Path) -> trimesh.Trimesh:
    """Load a mesh ensuring it is triangulated and cleaned up."""

    mesh = trimesh.load(path, force="mesh")
    if isinstance(mesh, trimesh.Scene):
        mesh = mesh.dump(concatenate=True)
    if not isinstance(mesh, trimesh.Trimesh):
        raise MeshProcessingError(f"Unsupported mesh type for {path}")
    if mesh.is_empty:
        raise MeshProcessingError(f"Mesh {path} has no geometry")
    mesh = mesh.copy()
    mesh.remove_unreferenced_vertices()
    mesh.remove_degenerate_faces()
    mesh.remove_duplicate_faces()
    mesh.remove_infinite_values()
    if not mesh.is_watertight:
        mesh.fill_holes()
    mesh.fix_normals()
    return mesh


def _detect_bottom_faces(mesh: trimesh.Trimesh) -> np.ndarray:
    """Return indices of faces that belong to the base at z≈0."""

    z_min = float(mesh.vertices[:, 2].min())
    z_max = float(mesh.vertices[:, 2].max())
    height = max(z_max - z_min, 1e-6)
    tol = max(height * 0.002, 0.1)
    faces = mesh.faces
    vertices = mesh.vertices
    face_min_z = vertices[faces][:, :, 2].min(axis=1)
    bottom_idx = np.where(face_min_z <= z_min + tol)[0]
    return bottom_idx


def _build_face_adjacency_list(mesh: trimesh.Trimesh) -> list[list[int]]:
    """Return adjacency list for faces."""

    n_faces = len(mesh.faces)
    neighbors: list[list[int]] = [[] for _ in range(n_faces)]
    if mesh.face_adjacency.shape[0] == 0:
        return neighbors
    for a, b in mesh.face_adjacency:
        neighbors[a].append(b)
        neighbors[b].append(a)
    return neighbors


def _detect_top_layer_faces(mesh: trimesh.Trimesh) -> np.ndarray:
    """Detect faces belonging to the last layer by scanning from the highest centroid."""

    centroids = mesh.triangles_center
    normals = mesh.face_normals
    z_min = float(centroids[:, 2].min())
    z_max = float(centroids[:, 2].max())
    height = max(z_max - z_min, 1e-6)

    # Define bands for seeding and growth
    seed_band = max(height * 0.02, 1.0)
    growth_band = max(height * 0.1, 6.0)

    seed_mask = (centroids[:, 2] >= z_max - seed_band) & (normals[:, 2] >= 0.0)
    seed_indices = np.where(seed_mask)[0]
    if seed_indices.size == 0:
        seed_indices = np.array([int(np.argmax(centroids[:, 2]))])

    allowed = (
        (centroids[:, 2] >= z_max - growth_band)
        & (normals[:, 2] >= -0.1)
    )

    neighbors = _build_face_adjacency_list(mesh)
    top_mask = np.zeros(len(mesh.faces), dtype=bool)
    queue: deque[int] = deque(seed_indices.tolist())
    top_mask[seed_indices] = True

    while queue:
        face = queue.popleft()
        for nb in neighbors[face]:
            if top_mask[nb] or not allowed[nb]:
                continue
            if centroids[nb, 2] > z_max + 1e-6:
                continue
            top_mask[nb] = True
            queue.append(nb)

    return np.where(top_mask)[0]


def segment_mesh(path: Path) -> SegmentMeshes:
    """Load and split a mesh into bottom, body, and top."""

    mesh = load_mesh(path)
    bottom_idx = _detect_bottom_faces(mesh)
    top_idx = _detect_top_layer_faces(mesh)

    n_faces = len(mesh.faces)
    body_mask = np.ones(n_faces, dtype=bool)
    body_mask[bottom_idx] = False
    if top_idx.size:
        body_mask[top_idx] = False

    bottom_mesh = mesh.submesh([bottom_idx], append=True) if bottom_idx.size else None
    body_mesh = mesh.submesh([np.where(body_mask)[0]], append=True) if body_mask.any() else None
    top_mesh = mesh.submesh([top_idx], append=True) if top_idx.size else None

    return SegmentMeshes(original=mesh, bottom=bottom_mesh, body=body_mesh, top=top_mesh)
